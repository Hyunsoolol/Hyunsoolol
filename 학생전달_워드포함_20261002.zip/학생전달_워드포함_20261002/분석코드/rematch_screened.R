﻿options(encoding='UTF-8',stringsAsFactors=FALSE)
if(.Platform$OS.type=='windows') invisible(Sys.setlocale('LC_CTYPE','English_United States.utf8'))
f<-sub('^--file=','',commandArgs()[grep('^--file=',commandArgs())][1]);setwd(dirname(normalizePath(f)))
read<-function(f){h<-names(read.csv(f,fileEncoding='UTF-8-BOM',nrows=0));cl<-rep(NA_character_,length(h));cl[h %in% c('admin_code','control_code','treated_code')]<-'character';read.csv(f,fileEncoding='UTF-8-BOM',colClasses=cl)}
save<-function(d,f)write.csv(d,f,row.names=FALSE,fileEncoding='UTF-8',na='')
d<-read('psm_input_four.csv');s<-read('scores.csv');e<-read('preperiod_eligibility.csv');oldrisk<-read('existing_risk_exclusions.csv')$admin_code;cases<-read('cases.csv')
checks<-c('log_population','youth_ratio_19_34','log1p_businesses_ALL','log1p_workers_ALL','commerce_share','manufacturing_businesses_share','manufacturing_workers_share');d<-d[complete.cases(d[checks]),]
pairs<-list()
for(model in c('M0','M1','M2')){
 a<-merge(d,s[s$model==model,c('admin_code','logit','score')],by='admin_code');width<-.2*sd(a$logit)
 for(riskname in c('existing','screened')){
  risk<-c(oldrisk,if(riskname=='screened')c('4521051000','4311167000') else character())
  for(i in seq_len(nrow(cases))){
   z<-cases[i,];t<-a[a$admin_code==z$treated_code,];eligible<-e$control_code[e$site==z$site & tolower(as.character(e$five_preyears_complete))=='true']
   pool<-a[a$treated==0 & a$province==t$province & a$admin_code %in% eligible & !a$admin_code %in% risk,]
   common<-t$logit>=min(pool$logit) && t$logit<=max(pool$logit);pool$distance<-abs(pool$logit-t$logit)
   pool<-pool[pool$distance<=width & common,];pool<-pool[order(pool$distance,pool$admin_code),]
   for(ratio in 1:3){
    if(nrow(pool)<ratio)next
    c<-head(pool,ratio);pairs[[length(pairs)+1]]<-data.frame(model=model,risk=riskname,ratio=ratio,site=z$site,opening=z$opening,treated_code=z$treated_code,rank=seq_len(ratio),control_code=c$admin_code,control_name=c$region_name,distance=c$distance)
   }
  }
 }
}
m<-do.call(rbind,pairs);primary<-m[m$model=='M2' & m$risk=='screened' & m$ratio==3,]
stopifnot(nrow(primary)==15,length(unique(primary$site))==5)
for(k in 1:3){x<-primary[primary$rank!=k,];x$risk<-paste0('screened_leave_rank',k);x$ratio<-2;m<-rbind(m,x)}
save(m,'matches_rematched.csv');cat('Standalone R rematching complete:',nrow(m),'pairs; primary:',nrow(primary),'\n')
