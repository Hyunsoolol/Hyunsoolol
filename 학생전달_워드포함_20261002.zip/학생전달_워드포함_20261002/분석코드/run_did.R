﻿options(encoding='UTF-8',stringsAsFactors=FALSE)
if(.Platform$OS.type=='windows') invisible(Sys.setlocale('LC_CTYPE','English_United States.utf8'))
f<-sub('^--file=','',commandArgs()[grep('^--file=',commandArgs())][1]);setwd(dirname(normalizePath(f)))
read<-function(f){h<-names(read.csv(f,fileEncoding='UTF-8-BOM',nrows=0));cl<-rep(NA_character_,length(h));cl[h %in% c('unit','actual_admin_code','treated_code','control_code')]<-'character';read.csv(f,fileEncoding='UTF-8-BOM',colClasses=cl)}
save<-function(d,f)write.csv(d,f,row.names=FALSE,fileEncoding='UTF-8',na='')
pan<-read('panel.csv');pairs<-read('matches.csv');met<-c('population','youth_ratio_19_34','net_migration','businesses_ALL','businesses_G','businesses_I','workers_ALL','workers_G','workers_I','workers_R')
stopifnot(!anyDuplicated(pan[c('site','unit','year')]),length(unique(pairs$site))==5)
res<-list();excluded<-list();annual<-list();events<-list();qc<-list();count<-0
cat(R.version.string,'\nModel: y ~ factor(unit) + factor(year) + treated*post interaction only\nFive-case operational scope; NO causal p-values/CI asserted.\n')
sc<-unique(pairs[c('model','risk','ratio','site','opening','treated_code')])
for(i in seq_len(nrow(sc))){
 z<-sc[i,];sel<-pairs[pairs$model==z$model & pairs$risk==z$risk & pairs$ratio==z$ratio & pairs$site==z$site,]
 windows<-if(z$model=='M2' && z$risk=='screened' && z$ratio==3)c('primary','full_business_break_diagnostic','omit_2020_2021','post_through_2019','F1963_omit_2016','pretrend_linear_extension','log_scale') else 'primary'
 for(metric in met) for(window in windows){
  bus<-grepl('^(businesses|workers)',metric)
  if(window=='full_business_break_diagnostic' && !bus)next
  if(window %in% c('omit_2020_2021','post_through_2019') && bus)next
  if(window=='F1963_omit_2016' && z$site!='F1963')next
  years<-c(seq(z$opening-5,z$opening-1),seq(z$opening+1,z$opening+5))
  if(bus && window!='full_business_break_diagnostic')years<-years[years<=2019]
  if(window=='omit_2020_2021')years<-years[!years %in% c(2020,2021)]
  if(window=='post_through_2019')years<-years[years<=2019]
  if(window=='F1963_omit_2016' && z$site=='F1963')years<-years[years!=2016]
  p<-pan[pan$site==z$site & pan$unit %in% c(z$treated_code,sel$control_code) & pan$year %in% years,]
  id<-data.frame(model=z$model,risk=z$risk,ratio=z$ratio,site=z$site,metric=metric,window=window)
  reason<-''
  if(length(unique(p$unit))!=z$ratio+1 || nrow(p)!=(z$ratio+1)*length(years) || anyNA(p[[metric]]))reason<-'incomplete fixed-donor panel; no imputation or available-donor averaging'
  if(!any(years<z$opening)||!any(years>z$opening))reason<-'no pre or post observations'
  if(nzchar(reason)){excluded[[length(excluded)+1]]<-cbind(id,reason=reason,expected_rows=(z$ratio+1)*length(years),observed_numeric=sum(!is.na(p[[metric]])));next}
  p$y<-p[[metric]]; transform<-'level'
  if(window=='log_scale'){
   if(metric=='population'){p$y<-log(p$y);transform<-'natural log'}
   else if(bus){p$y<-log1p(p$y);transform<-'log(1+x)'}
   else next
  }
  p$post<-as.integer(p$year>z$opening);p$did<-p$treated*p$post
  pre<-p[p$post==0,];post<-p[p$post==1,]
  tp<-mean(pre$y[pre$treated==1]);cp<-mean(pre$y[pre$treated==0]);tq<-mean(post$y[post$treated==1]);cq<-mean(post$y[post$treated==0]); arithmetic<-(tq-tp)-(cq-cp)
  fit<-lm(y~factor(unit)+factor(year)+did,data=p);beta<-unname(coef(fit)['did']);stopifnot(is.finite(beta),abs(beta-arithmetic)<1e-7)
  # Deterministic pre-gap trend extension, NOT a confidence interval or a proven correction.
  gaps<-aggregate(y~year+treated,p,mean);g<-merge(gaps[gaps$treated==1,c('year','y')],gaps[gaps$treated==0,c('year','y')],by='year',suffixes=c('_t','_c'));g$gap<-g$y_t-g$y_c
  gpre<-g[g$year<z$opening,];slope<-unname(coef(lm(gap~year,gpre))['year']);dt<-mean(years[years>z$opening])-mean(years[years<z$opening]);adjusted<-beta-slope*dt
  estimate<-if(window=='pretrend_linear_extension')adjusted else beta
  res[[length(res)+1]]<-cbind(id,estimate=estimate,raw_fe_did=beta,arithmetic_did=arithmetic,treated_pre=tp,treated_post=tq,control_pre=cp,control_post=cq,pre_years=paste(sort(unique(pre$year)),collapse=';'),post_years=paste(sort(unique(post$year)),collapse=';'),n_pre_years=length(unique(pre$year)),n_post_years=length(unique(post$year)),n_units=z$ratio+1,n_obs=nrow(p),rank=fit$rank,residual_df=fit$df.residual,pre_gap_slope=slope,pretrend_extension_adjusted=adjusted,transform=transform,causal_identification_certified=FALSE)
  qc[[length(qc)+1]]<-cbind(id,absolute_fe_arithmetic_difference=abs(beta-arithmetic))
  if(z$model=='M2' && z$risk=='screened' && z$ratio==3 && window=='primary'){
   g$site<-z$site;g$metric<-metric;g$opening<-z$opening;g$relative_year<-g$year-z$opening;annual[[length(annual)+1]]<-g
   # Saturated event-time interactions normalized to last pre year; reproduce relative gap changes.
   ref<-max(years[years<z$opening]);others<-years[years!=ref];names<-paste0('ev',seq_along(others))
   for(k in seq_along(others))p[[names[k]]]<-p$treated*as.integer(p$year==others[k])
   evfit<-lm(as.formula(paste('y~factor(unit)+factor(year)+',paste(names,collapse='+'))),data=p)
   ev<-unname(coef(evfit)[names]);refgap<-g$gap[g$year==ref];manual<-g$gap[match(others,g$year)]-refgap
   stopifnot(max(abs(ev-manual))<1e-7)
   events[[length(events)+1]]<-data.frame(site=z$site,metric=metric,year=c(ref,others),relative_year=c(ref,others)-z$opening,reference_year=ref,coefficient=c(0,ev),regression_estimated=c(FALSE,rep(TRUE,length(ev))),causal_event_effect=FALSE)
  }
  count<-count+1
 }
}
for(n in c('res','excluded','annual','events','qc')){x<-get(n);if(length(x))save(do.call(rbind,x),paste0(n,'.csv'))}
rr<-do.call(rbind,res);primary<-rr[rr$model=='M2' & rr$risk=='screened' & rr$ratio==3 & rr$window=='primary',];save(primary,'primary_results.csv')
cat('Executed FE regressions:',count,'\nPrimary:',nrow(primary),'\nExcluded:',length(excluded),'\nLargest arithmetic discrepancy:',max(do.call(rbind,qc)$absolute_fe_arithmetic_difference),'\n')
print(primary[c('site','metric','estimate','n_pre_years','n_post_years')],row.names=FALSE)
capture.output(sessionInfo(),file='sessionInfo.txt')
placebos<-list()
for(i in seq_len(nrow(primary))){
 z<-primary[i,];sel<-pairs[pairs$model=='M2' & pairs$risk=='screened' & pairs$ratio==3 & pairs$site==z$site,]
 fake<-unique(sel$opening)-3;years<-c(fake-2,fake-1,fake+1,fake+2)
 p<-pan[pan$site==z$site & pan$unit %in% c(sel$treated_code,sel$control_code) & pan$year %in% years,]
 if(nrow(p)!=16 || anyNA(p[[z$metric]]))next
 p$y<-p[[z$metric]];p$did<-p$treated*as.integer(p$year>fake)
 b<-unname(coef(lm(y~factor(unit)+factor(year)+did,p))['did'])
 placebos[[length(placebos)+1]]<-data.frame(site=z$site,metric=z$metric,fake_opening=fake,preyears=paste(c(fake-2,fake-1),collapse=';'),postyears=paste(c(fake+1,fake+2),collapse=';'),preperiod_placebo_did=b,p_value=NA_real_,causal_test=FALSE)
}
save(do.call(rbind,placebos),'preperiod_placebo.csv');cat('Pre-period placebo FE fits:',length(placebos),'\n')
