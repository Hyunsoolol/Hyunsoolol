﻿options(encoding='UTF-8',stringsAsFactors=FALSE)
if(.Platform$OS.type=='windows') invisible(Sys.setlocale('LC_CTYPE','English_United States.utf8'))
f<-sub('^--file=','',commandArgs()[grep('^--file=',commandArgs())][1]);setwd(dirname(normalizePath(f)))
read<-function(f){h<-names(read.csv(f,fileEncoding='UTF-8-BOM',nrows=0));cl<-rep(NA_character_,length(h));cl[h %in% c('admin_code','control_code')]<-'character';read.csv(f,fileEncoding='UTF-8-BOM',colClasses=cl)}
save<-function(d,f)write.csv(d,f,row.names=FALSE,fileEncoding='UTF-8',na='')
d<-read('psm_input_four.csv');e<-read('preperiod_eligibility.csv');risk<-read('existing_risk_exclusions.csv')$admin_code
checks<-c('log_population','youth_ratio_19_34','log1p_businesses_ALL','log1p_workers_ALL','commerce_share','manufacturing_businesses_share','manufacturing_workers_share')
d<-d[complete.cases(d[checks]),];stopifnot(sum(d$treated)==5,!anyDuplicated(d$admin_code),!any(d$site=='B39',na.rm=TRUE))
models<-list(M0=c('log_population','youth_ratio_19_34','log1p_businesses_ALL'),M1=c('log_population','youth_ratio_19_34','manufacturing_workers_share'),M2=c('log_population','youth_ratio_19_34','log1p_businesses_ALL','manufacturing_workers_share'))
cat(R.version.string,'\nRows:',nrow(d),'Treated:',sum(d$treated),'\n')
fitdiag<-list();coefrows<-list();scores<-list();support<-list();pairs<-list();balance<-list();overall<-list();scenarios<-list()
for(name in names(models)){
 vars<-models[[name]];z<-as.data.frame(scale(d[vars]));z$treated<-d$treated
 fit<-glm(treated~.,data=z,family=binomial(),control=glm.control(maxit=100,epsilon=1e-10))
 stopifnot(fit$converged,all(is.finite(coef(fit))))
 a<-d;a$logit<-predict(fit,type='link');a$score<-plogis(a$logit);width<-.2*sd(a$logit)
 X<-model.matrix(fit);H<-crossprod(X,X*(a$score*(1-a$score)))
 fitdiag[[length(fitdiag)+1]]<-data.frame(model=name,rows=nrow(a),treated=5,converged=fit$converged,iterations=fit$iter,max_abs_gradient=max(abs(crossprod(X,a$score-a$treated))),information_condition=kappa(H,exact=TRUE),caliper=width)
 coefrows[[length(coefrows)+1]]<-data.frame(model=name,term=names(coef(fit)),coefficient=unname(coef(fit)))
 sc<-a[c('admin_code','site','treated','logit','score')];sc$model<-name;scores[[length(scores)+1]]<-sc
 for(rs in c('existing','add_Moonhyeon1_2020_approval')){
  risks<-if(rs=='existing')risk else c(risk,'2629068000');mp<-list()
  for(i in which(a$treated==1)){
   t<-a[i,];elig<-e$control_code[e$site==t$site & tolower(as.character(e$five_preyears_complete))=='true']
   pool<-a[a$treated==0 & a$province==t$province & a$admin_code %in% elig & !a$admin_code %in% risks,]
   common<-nrow(pool)>0 && t$logit>=min(pool$logit) && t$logit<=max(pool$logit)
   pool$distance<-abs(pool$logit-t$logit);c<-pool[pool$distance<=width & common,];c<-c[order(c$distance,c$admin_code),]
   support[[length(support)+1]]<-data.frame(model=name,risk_scenario=rs,site=t$site,complete_pre_pool=nrow(pool),common_support=common,within_caliper=nrow(c),caliper=width)
   if(nrow(c)){
    chosen<-head(c,3);pair<-data.frame(model=name,risk_scenario=rs,site=t$site,rank=seq_len(nrow(chosen)),treated_code=t$admin_code,control_code=chosen$admin_code,control_name=chosen$region_name,distance=chosen$distance,causal_control=FALSE)
    mp[[length(mp)+1]]<-pair;pairs[[length(pairs)+1]]<-pair
    for(r in 1:3){
     if(nrow(c)<r)next
     cc<-head(c,r)
     for(v in checks){
      denom<-sd(pool[[v]]);gap<-(t[[v]]-mean(cc[[v]]))/denom
      balance[[length(balance)+1]]<-data.frame(model=name,risk_scenario=rs,site=t$site,ratio=r,variable=v,standardized_case_gap=gap,denominator='same-province precomplete risk-screened unmatched controls SD',reference_0_1=abs(gap)<=.1)
     }
    }
   }
  }
  cp<-if(length(mp))do.call(rbind,mp) else data.frame()
  for(r in 1:3){
   cc<-if(nrow(cp))cp[cp$rank<=r,] else cp;count<-if(nrow(cc))table(cc$site) else integer()
   full<-length(count)==5 && all(count==r);mx<-NA_real_
   if(full){
    controls<-a[match(cc$control_code,a$admin_code),];ts<-a[a$treated==1,];gaps<-numeric()
    for(v in checks){gap<-(mean(ts[[v]])-mean(controls[[v]]))/sd(a[[v]][a$treated==0]);gaps<-c(gaps,gap);overall[[length(overall)+1]]<-data.frame(model=name,risk_scenario=rs,ratio=r,variable=v,standardized_difference=gap,denominator='full complete unmatched control sample SD')}
    mx<-max(abs(gaps))
   }
   scenarios[[length(scenarios)+1]]<-data.frame(model=name,risk_scenario=rs,ratio=r,sites_with_full_ratio=sum(count==r),selected_pairs=length(if(nrow(cc))cc$control_code else character()),all_five_full_ratio=full,max_abs_overall_gap=mx,balance_reference_pass=full && mx<=.1,causal_controls_confirmed=FALSE)
  }
 }
}
for(n in c('fitdiag','coefrows','scores','support','pairs','balance','overall','scenarios')){x<-get(n);if(length(x))save(do.call(rbind,x),paste0(n,'.csv'))}
print(do.call(rbind,fitdiag));print(subset(do.call(rbind,support),model=='M2'));print(do.call(rbind,scenarios))
capture.output(sessionInfo(),file='sessionInfo.txt')
